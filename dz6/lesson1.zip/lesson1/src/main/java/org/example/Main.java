package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Animal {
    private String name;
    private String species;
    private int age;

}

public class Enclosure {
    private int capacity;
    private String type;

}

public class ZooManagementSystem {
    private List<Animal> animals;
    private Map<Enclosure, List<Animal>> enclosureMap;

    public ZooManagementSystem() {
        animals = new ArrayList<>();
        enclosureMap = new HashMap<>();
    }

    public void addAnimal(Animal animal, Enclosure enclosure) {
    }

    public void addEnclosure(Enclosure enclosure) {
    }

    public void viewAllAnimalsAndEnclosures() {

    }

    public void viewAnimalDetails(Animal animal) {
    }

    public void viewEnclosureDetails(Enclosure enclosure) {
    }

    public void editAnimal(Animal animal) {
    }

    public void moveAnimal(Animal animal, Enclosure newEnclosure) {
    }

    public void deleteAnimal(Animal animal) {

    }

    public void deleteEnclosure(Enclosure enclosure) {
    }

    public List<Animal> searchAnimalsByCharacteristics(String searchCriteria) {
        return new ArrayList<>();
    }

    public void saveDataToFile() {
    }

    public void loadDataFromFile() {
    }
}
